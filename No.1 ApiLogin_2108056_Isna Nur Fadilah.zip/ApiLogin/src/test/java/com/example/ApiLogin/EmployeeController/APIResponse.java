package com.example.ApiLogin.EmployeeController;

public class APIResponse {
}
