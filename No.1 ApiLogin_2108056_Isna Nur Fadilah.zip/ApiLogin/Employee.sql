SELECT "Id", "Email", "Username", "Password"
	FROM public.employee;